---STORY---

Your party enters a deep and dark dungeon� but sacrifices must be made. Only way forward is creative use of friendly fire.

Control 3 different heroes: a knight, a mage and a rogue, use their special abilities and sacrifice your teammates to reach the goal. As long as one hero survives, you complete the level.

---CONTROLS---

Arrow keys to Move
Z to Jump
X to use character's attack
A and S to cycle heroes
M mute music 
N to mute sounds

Esc return to stage select.

---MISC INFO---

Made for Ludum Dare 43, theme: Sacrifices must be made, in under 48 hours
Created with Stencyl www.stencyl.com

Made by Jussi Simpanen aka AdventureIslands
http://simpanen.carbonmade.com
adventureislands.deviantart.com
@AdventIslands on Twitter

--
 
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
http://creativecommons.org/licenses/by-nc-sa/3.0/